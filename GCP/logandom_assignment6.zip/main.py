from flask import Flask, request, jsonify
from google.cloud import datastore, storage
from jwt_util import verify_jwt, AuthError
import requests
import json
from authlib.integrations.flask_client import OAuth
import errors  

app = Flask(__name__)
app.secret_key = 'SECRET_KEY'

datastore_client = datastore.Client()
storage_client = storage.Client()

CLIENT_ID = 'BbQAhliFM04okwaSSgb1uCvVzc52MxnA'
CLIENT_SECRET = 'xtxEoVtrbEQcVq2hdWdDJT0Z80h79CQb-TmjCHU-PtSGOw0yaADe7xCpc_9jRnt1'
DOMAIN = 'dev-v7mpz23ulj2e03cd.us.auth0.com'

ALGORITHMS = ["RS256"]

AVATAR_BUCKET= 'hw6_bucket_logandom'

oauth = OAuth(app)

auth0 = oauth.register(
    'auth0',
    client_id=CLIENT_ID,
    client_secret=CLIENT_SECRET,
    api_base_url="https://" + DOMAIN,
    access_token_url="https://" + DOMAIN + "/oauth/token",
    authorize_url="https://" + DOMAIN + "/authorize",
    client_kwargs={
        'scope': 'openid profile email',
    },
)

@app.errorhandler(AuthError)
def handle_auth_error(ex):
    response = jsonify(ex.error)
    response.status_code = ex.status_code
    return response

@app.route('/')
def index():
    return "hello world"

@app.route('/decode', methods=['GET'])
def decode_jwt():
    payload = verify_jwt(request)
    return payload

@app.route('/users/login', methods=['POST'])
def login_user():
    content = request.get_json()
    if not content or 'username' not in content or 'password' not in content:
        return errors.error_400()  # Using error function from errors.py
    
    username = content["username"]
    password = content["password"]
    body = {'grant_type': 'password',
            'username': username,
            'password': password,
            'client_id': CLIENT_ID,
            'client_secret': CLIENT_SECRET
            }
    headers = {'content-type': 'application/json'}
    url = 'https://' + DOMAIN + '/oauth/token'
    r = requests.post(url, json=body, headers=headers)
    response_data = json.loads(r.text)
    
    if r.status_code == 200:
        return jsonify({"token": response_data['id_token']}), 200
    elif r.status_code == 400:
        return errors.error_400()  
    else:
        return errors.error_401()  

@app.route('/users', methods=['GET'])
def get_users():
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401() 
        return jsonify(e.error), e.status_code

    user_sub = payload.get('sub') 

    client = datastore.Client()
    query = client.query(kind="users")
    users = list(query.fetch())

    admin_user = None
    for user in users:
        if user["role"] == "admin" and user["sub"] == user_sub:
            admin_user = user
            break
    if admin_user is None:
        return errors.error_403() 
    all_users = [{
        "id": user.key.id,
        "role": user["role"],
        "sub": user["sub"]
    } for user in users]
    
    return jsonify(all_users), 200

@app.route('/users/<user_id>', methods=['GET'])
def get_user(user_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()  
        return jsonify(e.error), e.status_code

    user_sub = payload.get('sub')
    client = datastore.Client()
    user_key = client.key("users", int(user_id))
    user = client.get(user_key)

    if not user or (payload.get('role') != 'admin' and user_sub != user["sub"]):
        return errors.error_403()  

    response = {
        "id": user.key.id,
        "role": user["role"],
        "sub": user["sub"]
    }

    if user.get("avatar_url"):
        response["avatar_url"] = user["avatar_url"]

    if user["role"] in ["instructor", "student"]:
        print(user.get("courses"))
        response["courses"] = user.get("courses", [])

    return jsonify(response), 200


@app.route('/users/<user_id>/avatar', methods=['POST'])
def upload_avatar(user_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()  
        return jsonify(e.error), e.status_code
    
    bucket = storage_client.bucket(AVATAR_BUCKET)
    if 'file' not in request.files:
        return errors.error_400()  

    file = request.files["file"]

    if not file.filename.endswith(".png"):
        return errors.error_400() 
    
    user_sub = payload.get('sub')
    client = datastore.Client()
    user_key = client.key("users", int(user_id))
    user = client.get(user_key)
    
    if not user or (user_sub != user["sub"] and payload.get("role") != "admin"):
        return errors.error_403()  
    
    avatar_blob = bucket.blob(f"{user_id}_avatar.png")
    file.seek(0)
    avatar_blob.upload_from_file(file)
    avatar_url = f"https://{request.host}/users/{user_id}/avatar"
    user["avatar_url"] = avatar_url
    datastore_client.put(user)
    return jsonify({"avatar_url": avatar_url}), 200

@app.route('/users/<user_id>/avatar', methods=['GET'])
def get_avatar(user_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()  
        return jsonify(e.error), e.status_code

    client = datastore.Client()
    user_key = client.key("users", int(user_id))
    user = client.get(user_key)

    if not user:
        return errors.error_404()  

    user_sub = payload.get("sub")
    if user_sub != user["sub"] and payload.get("role") != "admin":
        return errors.error_403()  

    if "avatar_url" not in user or not user["avatar_url"]:
        return errors.error_404()  

    bucket = storage_client.bucket(AVATAR_BUCKET)
    avatar_blob = bucket.blob(f"{user_id}_avatar.png")

    if not avatar_blob.exists():
        return errors.error_404()  

    response = avatar_blob.download_as_bytes()
    return response, 200, {
        "Content-Type": "image/png",
        "Content-Disposition": f"inline; filename={user_id}_avatar.png"
    }

@app.route('/users/<user_id>/avatar', methods=['DELETE'])
def delete_avatar(user_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()  
        return jsonify(e.error), e.status_code

    client = datastore.Client()
    user_key = client.key("users", int(user_id))
    user = client.get(user_key)

    if not user:
        return errors.error_404()  

    user_sub = payload.get("sub")
    if user_sub != user["sub"] and payload.get("role") != "admin":
        return errors.error_403() 

    if "avatar_url" not in user or not user["avatar_url"]:
        return errors.error_404()  

    bucket = storage_client.bucket(AVATAR_BUCKET)
    avatar_blob = bucket.blob(f"{user_id}_avatar.png")

    if not avatar_blob.exists():
        return errors.error_404()  

    avatar_blob.delete()
    user["avatar_url"] = None
    datastore_client.put(user)
    return '', 204

@app.route('/courses', methods=['POST'])
def create_course():
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()
        return jsonify(e.error), e.status_code

    course_data = request.get_json()

    required_fields = ["subject", "number", "title", "term", "instructor_id"]
    for field in required_fields:
        if field not in course_data:
            return errors.error_400()

    user_sub = payload.get("sub")

    client = datastore.Client()
    query = client.query(kind="users")
    query.add_filter("role", "=", "admin")
    query.add_filter("sub", "=", user_sub)
    admin_list = list(query.fetch())

    if not admin_list:
        return errors.error_403()

    instructor_id = course_data.get("instructor_id")

    all_users_query = client.query(kind="users")
    all_users = list(all_users_query.fetch())

    instructor = next((user for user in all_users if user.key.id == instructor_id and user["role"] == "instructor"), None)

    if not instructor:
        return errors.error_400()

    course_key = client.key("courses")
    new_course = datastore.Entity(course_key)
    new_course.update({
        "subject": course_data["subject"],
        "number": course_data["number"],
        "title": course_data["title"],
        "term": course_data["term"],
        "instructor_id": instructor_id,
    })
    client.put(new_course)

    course_url = f"{request.url}/{new_course.key.id}"

    return jsonify({
        "id": new_course.key.id,
        "subject": new_course["subject"],
        "number": new_course["number"],
        "title": new_course["title"],
        "term": new_course["term"],
        "instructor_id": new_course["instructor_id"],
        "self": course_url
    }), 201

@app.route('/courses', methods=['GET'])
def get_courses():
    offset = int(request.args.get('offset', 0))
    limit = int(request.args.get('limit', 3))

    client = datastore.Client()
    query = client.query(kind="courses")
    query.order = ["subject"]

    courses = list(query.fetch(offset=offset, limit=limit))

    course_list = []
    for course in courses:
        course_data = {
            "id": course.key.id,
            "subject": course["subject"],
            "number": course["number"],
            "title": course["title"],
            "term": course["term"],
            "instructor_id": course["instructor_id"],
            "self": f"{request.url}/{course.key.id}"
        }
        course_list.append(course_data)

    next_offset = offset + limit if len(courses) == limit else None
    next_url = None
    if next_offset:
        next_url = f"{request.base_url}?limit={limit}&offset={next_offset}"

    return jsonify({
        "courses": course_list,
        "next": next_url
    })

@app.route('/courses/<int:course_id>', methods=['GET'])
def get_course(course_id):
    client = datastore.Client()
    course_key = client.key("courses", course_id)
    course = client.get(course_key)

    if not course:
        return errors.error_404()

    course_data = {
        "id": course.key.id,
        "subject": course["subject"],
        "number": course["number"],
        "title": course["title"],
        "term": course["term"],
        "instructor_id": course["instructor_id"],
        "self": f"{request.url}"
    }

    return jsonify(course_data)

@app.route('/courses/<int:course_id>', methods=['PATCH'])
def update_course(course_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()  
        return jsonify(e.error), e.status_code

    user_sub = payload.get("sub")

    client = datastore.Client()
    query = client.query(kind="users")
    query.add_filter("role", "=", "admin")
    query.add_filter("sub", "=", user_sub)
    admin_list = list(query.fetch())

    if not admin_list:
        return errors.error_403()

    course_key = client.key("courses", course_id)
    course = client.get(course_key)

    if not course:
        return errors.error_404()  

    update_data = request.get_json()

    if "instructor_id" in update_data:
        instructor_id = update_data["instructor_id"]
        query = client.query(kind="users")
        query.add_filter("role", "=", "instructor")
        all_users = list(query.fetch())
        
        instructor = next((user for user in all_users if user.key.id == instructor_id), None)

        if not instructor:
            return errors.error_400()  

        course["instructor_id"] = instructor_id

    for key, value in update_data.items():
        if key != "instructor_id":
            course[key] = value

    client.put(course)

    course_data = {
        "id": course.key.id,
        "subject": course["subject"],
        "number": course["number"],
        "title": course["title"],
        "term": course["term"],
        "instructor_id": course["instructor_id"],
        "self": f"{request.url}"
    }

    return jsonify(course_data), 200

@app.route('/courses/<int:course_id>', methods=['DELETE'])
def delete_course(course_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()
        return jsonify(e.error), e.status_code

    user_sub = payload.get("sub")

    client = datastore.Client()
    query = client.query(kind="users")
    query.add_filter("role", "=", "admin")
    query.add_filter("sub", "=", user_sub)
    admin_list = list(query.fetch())

    if not admin_list:
        return errors.error_403()

    course_key = client.key("courses", course_id)
    course = client.get(course_key)

    if not course:
        return errors.error_404()

    enrollment_query = client.query(kind="enrollments")
    enrollment_query.add_filter("course_id", "=", course_id)
    enrollments = list(enrollment_query.fetch())

    for enrollment in enrollments:
        client.delete(enrollment.key)

    client.delete(course_key)

    return '', 204

@app.route('/courses/<int:course_id>/students', methods=['PATCH'])
def update_enrollment(course_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()  
        return jsonify(e.error), e.status_code

    user_sub = payload.get("sub")

    client = datastore.Client()
    course_key = client.key("courses", course_id)
    course = client.get(course_key)

    if not course:
        return errors.error_404()

    query = client.query(kind="users")
    query.add_filter("sub", "=", user_sub)
    user = list(query.fetch())

    if not user:
        return errors.error_401()

    if "admin" in [u["role"] for u in user] or course["instructor_id"] == user[0].key.id:
        add_students = request.json.get("add")
        remove_students = request.json.get("remove")

        if any(student in add_students for student in remove_students):
            return errors.error_409()

        all_users = list(client.query(kind="users").fetch())
        all_students = [user for user in all_users if user.get("role") == "student"]

        invalid_students = set(add_students + remove_students) - {student.key.id for student in all_students}
        if invalid_students:
            return errors.error_409()

        enrollment_query = client.query(kind="enrollments")
        enrollment_query.add_filter("course_id", "=", course_id)
        enrollments = list(enrollment_query.fetch())

        existing_enrollment_ids = {enrollment["student_id"] for enrollment in enrollments}

        for student_id in add_students:
            if student_id not in existing_enrollment_ids:
                enrollment = datastore.Entity(client.key("enrollments"))
                enrollment.update({
                    "course_id": course_id,
                    "student_id": student_id
                })
                client.put(enrollment)

        for student_id in remove_students:
            for enrollment in enrollments:
                if enrollment["student_id"] == student_id:
                    client.delete(enrollment.key)

        return jsonify({}), 200
    return errors.error_403()

@app.route('/courses/<int:course_id>/students', methods=['GET'])
def get_enrollment(course_id):
    try:
        payload = verify_jwt(request)
    except AuthError as e:
        if e.status_code == 401:
            return errors.error_401()
        return jsonify(e.error), e.status_code

    user_sub = payload.get("sub")

    client = datastore.Client()
    query = client.query(kind="users")
    query.add_filter("role", "=", "admin")
    query.add_filter("sub", "=", user_sub)
    admin_list = list(query.fetch())

    if not admin_list:
        course_key = client.key("courses", course_id)
        course = client.get(course_key)

        if not course:
            return errors.error_403()

        instructor_id = course.get("instructor_id")
        if instructor_id != user_sub:
            return errors.error_403()

    enrollment_query = client.query(kind="enrollments")
    enrollment_query.add_filter("course_id", "=", course_id)
    enrollments = list(enrollment_query.fetch())

    student_ids = [enrollment["student_id"] for enrollment in enrollments]

    return jsonify(student_ids), 200




if __name__ == '__main__':
    app.run(host='127.0.0.1', port=8080, debug=True)

