from flask import jsonify

def error_400():
    return jsonify({"Error": "The request body is invalid"}), 400

def error_401():
    return jsonify({"Error": "Unauthorized"}), 401

def error_403():
    return jsonify({"Error": "You don't have permission on this resource"}), 403

def error_404():
    return jsonify({"Error": "Not found"}), 404

def error_409():
    return jsonify({"Error": "Enrollment data is invalid"}), 409